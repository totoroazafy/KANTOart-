# KANTO-art — Android starter project

Version 1.0 starter: Kotlin Android app with a dark navy/blue interface, French + Malagasy labels,
photo import, brightness, contrast, saturation, black-and-white preset, a simple "Canon" preset,
reset, and JPEG export to Pictures/KANTO-art.

## Build an installable APK
1. Install Android Studio on a computer.
2. Open this folder (`KANTO-art-Android`) in Android Studio.
3. Allow Gradle sync and install any requested Android SDK platform (API 35).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio creates the APK under `app/build/outputs/apk/debug/`.

This ZIP contains the Android Studio project source, not a precompiled APK.
The current starter is intentionally a first version; advanced tools such as healing, curves,
selective editing, layers, crop UI, and background removal are not implemented yet.
