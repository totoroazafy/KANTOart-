package com.kantoart.editor

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.ContentValues
import android.os.Build
import android.graphics.drawable.GradientDrawable
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private var original: Bitmap? = null
    private var edited: Bitmap? = null
    private var brightness = 0
    private var contrast = 100
    private var saturation = 100
    private var grayscale = false
    private val blue = Color.rgb(39, 139, 255)
    private val bg = Color.rgb(8, 13, 24)
    private val panel = Color.rgb(17, 27, 45)
    private val white = Color.rgb(238, 244, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun rounded(color: Int, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun label(text: String, size: Float = 14f, color: Int = white): TextView =
        TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 12)
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "KANTO-art"
            textSize = 27f
            setTextColor(blue)
            typeface = Typeface.DEFAULT_BOLD
        }
        val sub = TextView(this).apply {
            text = "  PHOTO EDITOR  •  PRO"
            textSize = 10f
            setTextColor(Color.LTGRAY)
        }
        header.addView(brand)
        header.addView(sub)
        root.addView(header)
        val tagline = label("Retouche photo • Fanatsarana sary", 12f, Color.LTGRAY)
        root.addView(tagline)

        preview = ImageView(this).apply {
            background = rounded(panel)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageResource(android.R.drawable.ic_menu_gallery)
            setPadding(8, 8, 8, 8)
        }
        val imageParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        )
        imageParams.topMargin = 14
        imageParams.bottomMargin = 12
        root.addView(preview, imageParams)

        status = label("Choisissez une photo pour commencer • Misafidiana sary hanombohana", 12f, Color.LTGRAY)
        root.addView(status)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(actionButton("＋ Ouvrir / Hanokatra") { pickImage() }, weightParams())
        buttons.addView(actionButton("↺ Reset") { resetEdits() }, weightParams())
        buttons.addView(actionButton("Enregistrer / Tehirizo") { saveImage() }, weightParams())
        root.addView(buttons)

        addSlider(root, "Luminosité / Fahazavana", -100, 100, 0) { brightness = it; render() }
        addSlider(root, "Contraste / Fifanoherana", 0, 200, 100) { contrast = it; render() }
        addSlider(root, "Saturation / Hamafin'ny loko", 0, 200, 100) { saturation = it; render() }

        val filters = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        filters.addView(actionButton("Original") { grayscale = false; render() }, weightParams())
        filters.addView(actionButton("N&B") { grayscale = true; render() }, weightParams())
        filters.addView(actionButton("Canon") {
            grayscale = false
            brightness = 8
            contrast = 112
            saturation = 112
            render()
        }, weightParams())
        root.addView(filters)
        setContentView(root)
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, 46, 1f).apply {
        marginStart = 3; marginEnd = 3; topMargin = 5; bottomMargin = 5
    }

    private fun actionButton(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 10f
            isAllCaps = false
            setTextColor(white)
            background = rounded(Color.rgb(26, 54, 91), 14f)
            setOnClickListener { action() }
        }

    private fun addSlider(root: LinearLayout, title: String, minValue: Int, maxValue: Int,
                          initial: Int, onChange: (Int) -> Unit) {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 2, 10, 0)
            background = rounded(panel, 14f)
        }
        wrap.addView(label(title, 12f))
        val seek = SeekBar(this).apply {
            max = maxValue - minValue
            progress = initial - minValue
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    onChange(p + minValue)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        wrap.addView(seek)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = 5
        root.addView(wrap, lp)
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
        startActivityForResult(Intent.createChooser(intent, "Choisir une photo / Misafidiana sary"), 100)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                val bitmap = if (Build.VERSION.SDK_INT >= 28) {
                    val source = ImageDecoder.createSource(contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                        decoder.isMutableRequired = false
                    }
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(contentResolver, uri)
                }
                original = bitmap.copy(Bitmap.Config.ARGB_8888, true)
                brightness = 0; contrast = 100; saturation = 100; grayscale = false
                render()
                status.text = "Photo chargée • Tafiditra ny sary"
            } catch (e: Exception) {
                status.text = "Impossible d'ouvrir cette image • Tsy afaka manokatra sary"
            }
        }
    }

    private fun resetEdits() {
        brightness = 0; contrast = 100; saturation = 100; grayscale = false
        render()
    }

    private fun render() {
        val src = original ?: return
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val matrix = ColorMatrix()
        matrix.setSaturation(if (grayscale) 0f else saturation / 100f)
        val c = contrast / 100f
        val b = brightness.toFloat()
        val contrastMatrix = ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, b,
            0f, c, 0f, 0f, b,
            0f, 0f, c, 0f, b,
            0f, 0f, 0f, 1f, 0f
        ))
        matrix.postConcat(contrastMatrix)
        paint.colorFilter = ColorMatrixColorFilter(matrix)
        canvas.drawBitmap(src, 0f, 0f, paint)
        edited = out
        preview.setImageBitmap(out)
    }

    private fun saveImage() {
        val bitmap = edited ?: original
        if (bitmap == null) {
            status.text = "Ouvrez d'abord une photo • Sokafy aloha ny sary"
            return
        }
        try {
            val name = "KANTO_art_${System.currentTimeMillis()}.jpg"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/KANTO-art")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Storage unavailable")
            contentResolver.openOutputStream(uri)?.use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            } ?: throw Exception("Cannot write image")
            if (Build.VERSION.SDK_INT >= 29) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            }
            status.text = "Enregistré dans Pictures/KANTO-art • Voatahiry!"
        } catch (e: Exception) {
            status.text = "Erreur d'enregistrement • Nisy olana tamin'ny fitahirizana"
        }
    }
}
